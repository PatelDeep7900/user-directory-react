import { useEffect, useState } from "react";
import "./App.css";
import UserList from "./components/UserList";
import Loader from "./components/Loader";
import ErrorMessage from "./components/ErrorMessage";

function App() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
const [search, setSearch] = useState("");

  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/users")
      .then((res) => {
        if (!res.ok) {
          throw new Error("Failed to fetch users");
        }

        return res.json();
      })
      .then((data) => {
        setUsers(data);
        setLoading(false);
      })
      .catch((error) => {
        setError(error.message);  
        setLoading(false);
      });
  }, []);

const filteredUsers = users.filter((user) =>
  user.name.toLowerCase().includes(search.toLowerCase())
);

  return (
    <div className="app">
      <header className="header">
        <h1>Mini User Directory</h1>
        <p>Find users quickly by their name</p>
      </header>
      <main className="container">
        <div className="search-box">
          <input type="text" placeholder="Search user..." value={search} onChange={(event)=> setSearch(event.target.value)}></input>
        </div>
        {loading && <Loader />}
        {error && <ErrorMessage errors={error} />}

        {!loading && !error && <UserList users={filteredUsers} />}
      </main>
    </div>
  );
}

export default App;
